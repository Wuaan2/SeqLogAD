Semantic source-only bundle. Upload this entire folder to /content/phase2.
No raw corpus, labels, target evaluation or model weights included.
